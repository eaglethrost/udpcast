package lansync

import (
	"encoding/binary"
	"io"
	"net"
	"sync"
)

/*
Provider will scan dirs and creates a dirtree
broadcast a dirtree every 2 minutes of idle
	a dirtree will perhaps require more than a single pkt
	therefore there is sequences on every packt
	last sequence is marked with 0x80 bit

*/

type udpcomm struct {
	Id   int
	Node *Node
	conn *net.UDPConn
	//
	raddr,
	laddr *net.UDPAddr
	rlen int
	//
	bread,
	bwrit []byte
	//
	MGICList []uint16
	UdpNotify
	UdpPkt
	//
	sync.Mutex
}

type UdpNotify struct {
	MGIC  uint16
	TokId uint16
	Cmd,
	Seq byte
}

func (me *UdpNotify) packNotify() (p []byte, err error) {
	p = make([]byte, 4)
	binary.BigEndian.PutUint16(p, me.MGIC)
	binary.BigEndian.PutUint16(p, me.TokId)
	p[4] = me.Cmd
	p[5] = me.Seq

	return
}

func (me *UdpNotify) unpackNotify(p []byte) (err error) {
	me.MGIC = binary.BigEndian.Uint16(p[:2])  //the header
	me.TokId = binary.BigEndian.Uint16(p[2:]) //the header
	me.Cmd = p[4]
	me.Seq = p[5]

	return
}

// this struct can be pack in 4 ways:
// pack only the header: 4 bytes
// pack header with param: 16 bytes
// pack the header with payload: PKTMaxLength
// pack the header with payload: PKTMaxLength and Encrypted
type UdpPkt struct {
	UdpHeader [4]byte
	Param     [10]byte //
	PSize     uint16   //
	Payload   [PKTMaxLength - 16]byte
}

// //pack the udppacket with load
// func (me *UdpPkt) packPkt() (p []byte, err error) {

// 	buf := new(bytes.Buffer)
// 	err = binary.Write(buf, binary.BigEndian, me)
// 	if err != nil {
// 		err = fmt.Errorf("binwrite>%v", err)
// 		return
// 	}

// 	p = buf.Bytes()
// 	return
// }

// func (me *UdpPkt) unpackPkt(p []byte) (err error) {
// 	buf := bytes.NewReader(p)
// 	err = binary.Read(buf, binary.BigEndian, me)
// 	if err != nil {
// 		err = fmt.Errorf("binread>%v", err)
// 		return
// 	}

// 	return
// }

// to make announcement, broadcasting, spread commmand.
func (me *udpcomm) Feedback(cmd byte, p []byte) (err error) {
	// me.sendTo(pkt, me.raddr.IP)
	return
}

// to send a packet specified to destination
func (me *udpcomm) Read() (MGIC uint16, err error) {
	var rlen, xlen int

	for {
		me.rlen, me.raddr, err = me.conn.ReadFromUDP(me.bread)
		if err != nil {
			var emsg string
			if err == io.ErrClosedPipe {
				emsg = "ClosedPipe"
			} else {
				emsg = "Other"
			}

			L.ERR(err, "ub.Read %s fr:%v", emsg, me.raddr)
			return
		}

		if err = me.unpackNotify(me.bread); err != nil {
			L.ERR(err, "ub.Read fr:%v", me.raddr)
			continue
		}

		//-----show the read data only 32 first bytes.
		if rlen < 32 {
			xlen = rlen
		} else {
			xlen = 32
		}
		L.DBG("[%d] In Pkt:%X %#v /%s/ fr:%v",
			me.Id,
			me.bread[:xlen],
			me.UdpNotify,
			cmds[me.Cmd],
			me.raddr,
		)

		//---- if the MGIC is within our list,
		//---- then we can return, unless ignore it.
		for _, mgic := range me.MGICList {
			if mgic == me.MGIC {
				return me.MGIC, nil
			}
		}

		break
	}
	return me.MGIC, nil
	// if raddr.Port == me.laddr.Port {
	// 	//ignore local packet (loopback)
	// 	//even only 1 sock, packet still reverb back
	// 	goto reread
	// }
	// me.PSize = binary.BigEndian.Uint16(me.bread[4:])

}
