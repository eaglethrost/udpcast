package lansync

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"runtime"
	"time"
)

// this routine is listening from a broadcast pkt (Member)
func (me *Node) listener(uc *udpcomm) {
	var err error
	var MGIC uint16

	runtime.LockOSThread()

	L.INF("Listener starts:%d", uc.Id)
	me.listenok <- 1
	for {
		if MGIC, err = uc.Read(); err != nil {
			err = fmt.Errorf("Listener>%v", err)
			L.ERR(err, "Socket Read:%d", uc.Id)
			return
		}

		if MGIC == MGICBC_NOTIFY {
			me.Notif(uc)

		} else if me.ServerIs {
			me.ListenServer(MGIC, uc)

		} else {
			me.ListenPeer(MGIC, uc)
		}
	}
}

/*
process notification from any nodes: server and peer
*/
func (me *Node) Notif(uc *udpcomm) (err error) {
	switch uc.Cmd {
	case CMD_WHOISTHESERVER:
		//if you are the Server, then you should answer this, unless ignore it.
		L.INF("Get Who Is The Server request, fr:%v", uc.raddr)
		if me.ServerIs {
			L.INF("Bcast I Am The Server")
			err = me.SendPkt(MGICBC_NOTIFY, CMD_IAMTHESERVER, nil)
			if err != nil {
				L.ERR(err, "I Am The Server, fail")
			}
		}
		return

	case CMD_IAMTHESERVER:
		nc := time.Since(me.lastClaim) < time.Duration(TICKS_DELAYSERVERCLAIM)*time.Millisecond
		if me.Server == nil { //new claim,
			L.INF("Get I am Server! nc:%t fr:%v", nc, uc.raddr)
			//if there is a new node claim as Server, accept it.
			me.Server = uc.raddr
			me.ServerIs = uc.TokId == me.NoId
			if me.ServerIs {
				L.INF("%04X We are The Server fr:%v %v",
					uc.TokId, uc.raddr, me.uc[0].laddr)
			}

			me.lastClaim = time.Now()
		}
		return

	}

	return
}

func (me *Node) ListenPeer(MGIC uint16, uc *udpcomm) (err error) {
	switch MGIC {
	case MGICSV_FILEINFO:
		// me.FInfoRsp(uc)

	case MGICSV_DATABLOK:
		me.DataBlock(uc)

	default:
		L.Warn(me.NoId, 0xFFFF,
			"2MGIC:%04X not recognize fr:%s",
			MGIC,
			uc.raddr.IP.String(),
		)
	}

	return
}

func (me *Node) ListenServer(MGIC uint16, uc *udpcomm) (err error) {
	var bo *bytes.Buffer
	var finfo FInfo

	switch MGIC {
	case MGICBC_FEEDBACK:
		me.Feedback(uc)

	case MGICSV_FILEINFO:
		L.INF("Num Fileinfo: %d\n%X", uc.Seq, uc.bread[6:38])
		bo = bytes.NewBuffer(uc.bread[6:])

		for i := byte(0); i < uc.Seq; i++ {
			binary.Read(bo, binary.BigEndian, &finfo)
			L.INF("\tFInfo:%d/%d|%v", i, uc.Seq, finfo)
		}
		// me.FInfoReq(uc)

	default:
		L.Warn(me.NoId, 0xFFFF,
			"MGIC:%04X not recognize fr:%s",
			MGIC,
			uc.raddr.IP.String(),
		)
	}

	return
}

func (me *Node) Feedback(uc *udpcomm) (err error) {

	switch uc.Cmd {
	case CMD_JOIN_XX1:
	default:
	}
	return
}

func (me *Node) DataBlock(uc *udpcomm) (err error) {

	return
}
