package lansync

import (
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"syscall"

	"golang.org/x/sys/unix"
)

/*
now := time.Now()      // current local time
sec := now.Unix()      // number of seconds since January 1, 1970 UTC
nsec := now.UnixNano() // number of nanoseconds since January 1, 1970 UTC

fmt.Println(now)  // time.Time
fmt.Println(sec)  // int64
fmt.Println(nsec) // int64

*/

// func (me *FileInfo) pack() (binfo []byte, blen int, err error) {
// 	var slen byte
// 	bf := new(bytes.Buffer)
// 	// utime := uint64(me.fi.ModTime().Unix())
// 	// ugid := me.fi.Sys().(*syscall.Stat_t)
// 	// me.Uid = ugid.Uid
// 	// me.Gid = ugid.Gid
// 	// me.FSize = me.fi.Size()
// 	// me.Mode = uint32(me.fi.Mode())

// 	binary.Write(bf, binary.BigEndian, me.Isdir)
// 	binary.Write(bf, binary.BigEndian, me.UmodTime)
// 	binary.Write(bf, binary.BigEndian, me.FSize)
// 	binary.Write(bf, binary.BigEndian, me.Mode)
// 	binary.Write(bf, binary.BigEndian, me.Crc32) //crc32
// 	binary.Write(bf, binary.BigEndian, me.Uid)
// 	binary.Write(bf, binary.BigEndian, me.Gid)
// 	binary.Write(bf, binary.BigEndian, me.phash)
// 	binary.Write(bf, binary.BigEndian, me.fhash)
// 	slen = byte(len(me.Fname))
// 	binary.Write(bf, binary.BigEndian, slen)
// 	bf.Write([]byte(me.Fname))
// 	binfo = bf.Bytes()
// 	blen = bf.Len()

// 	return
// }

// func (me *FileInfo) bpack(bf *bytes.Buffer) (err error) {
// 	var slen byte

// 	binary.Write(bf, binary.BigEndian, me.Isdir)
// 	binary.Write(bf, binary.BigEndian, me.UmodTime)
// 	binary.Write(bf, binary.BigEndian, me.FSize)
// 	binary.Write(bf, binary.BigEndian, me.Mode)
// 	binary.Write(bf, binary.BigEndian, me.Crc32) //crc32
// 	binary.Write(bf, binary.BigEndian, me.Uid)
// 	binary.Write(bf, binary.BigEndian, me.Gid)
// 	binary.Write(bf, binary.BigEndian, me.phash)
// 	binary.Write(bf, binary.BigEndian, me.fhash)
// 	slen = byte(len(me.Fname))
// 	binary.Write(bf, binary.BigEndian, slen)
// 	bf.Write([]byte(me.Fname))

// 	return
// }

// func (me *FileInfo) unpack(bh []byte) (err error) {
// 	var slen byte
// 	var n int

// 	me = new(FileInfo)
// 	bf := bytes.NewBuffer(bh)
// 	binary.Read(bf, binary.BigEndian, &me.Isdir)
// 	binary.Read(bf, binary.BigEndian, &me.UmodTime)
// 	binary.Read(bf, binary.BigEndian, &me.FSize)
// 	binary.Read(bf, binary.BigEndian, &me.Mode)
// 	binary.Read(bf, binary.BigEndian, &me.Crc32)
// 	binary.Read(bf, binary.BigEndian, &me.Uid)
// 	binary.Read(bf, binary.BigEndian, &me.Gid)
// 	binary.Read(bf, binary.BigEndian, &me.phash)
// 	binary.Read(bf, binary.BigEndian, &me.fhash)
// 	binary.Read(bf, binary.BigEndian, &slen)
// 	bname := make([]byte, slen)
// 	n, err = bf.Read(bname)
// 	me.Fname = string(bname[:n])

// 	return
// }

//scans me.fpath directory
func (me *FileInfo) scan() (err error) {
	var files []fs.DirEntry
	var fi fs.FileInfo
	var name string
	var finfo *FileInfo
	var wd int
	var ok bool

	files, err = os.ReadDir(me.fpath)
	if err != nil {
		err = fmt.Errorf("readdir(%s)>%v", me.fpath, err)
		return
	}
	//add notify watch at first
	wd, err = unix.InotifyAddWatch(
		me.Node.fd,
		me.fpath,
		agnosticEvents,
	)
	if wd == -1 || err != nil {
		err = fmt.Errorf("scan(%s)>%v", me.fpath, err)
		return
	}
	me.Node.watch[wd] = me

	L.DBG("Read Dir:%s Contain %d files", me.fpath, len(files))
	for _, file := range files {
		name = filepath.Clean(file.Name())
		if file.IsDir() {
			if me.Node.rgxExcl.Match([]byte(name)) {
				//excluded folder, ignore it.
				L.WRN("Excluded:'%s'", name)
				continue
			}
		}

		if fi, err = file.Info(); err != nil {
			err = fmt.Errorf("finfo(%s)>%v", name, err)
			continue
		}

		//fill in the list of namehash
		finfo, ok = me.member[mHash(name)]
		switch {
		case !ok:
			finfo = me.new(name)
			finfo.Op = FSCANNED

		case finfo.UmodTime != fi.ModTime().Unix():
			finfo.UmodTime = fi.ModTime().Unix()
			finfo.Op = FUPDATED

		case finfo.FSize != fi.Size():
			finfo.FSize = fi.Size()
			finfo.Op = FUPDATED

		default:
			continue
		}

		me.Node.mfc <- finfo
		if !finfo.Isdir {
			continue
		}

		// L.INF("scan:%s", finfo.fpath)
		if err = finfo.scan(); err != nil {
			err = fmt.Errorf("recurse(%s)>%v",
				finfo.fpath, err,
			)
			return
		}
	}

	return
}

func (me *FileInfo) new(name string) (finfo *FileInfo) {

	otyp := "FILE"
	_ = otyp

	fhash := mHash(name)
	finfo = &FileInfo{
		parent: me,
		Node:   me.Node,
		member: make(map[uint32]*FileInfo),
		Fname:  name,
		phash:  me.fhash,
		fhash:  fhash,
		fpath:  me.fpath + "/" + name,
		Op:     FCREATE,
	}
	// finfo.Fname = name
	Fsinfo, err := os.Stat(finfo.fpath)
	if err != nil {
		L.ERR(err, "os.stat %s", finfo.fpath)
		return nil
	}
	finfo.Isdir = Fsinfo.IsDir()
	if finfo.Isdir {
		otyp = "DIR "
	}
	finfo.UmodTime = Fsinfo.ModTime().Unix()
	finfo.FSize = Fsinfo.Size()
	finfo.Mode = uint32(Fsinfo.Mode())
	ugid := Fsinfo.Sys().(*syscall.Stat_t)
	finfo.Uid = ugid.Uid
	finfo.Gid = ugid.Gid

	// L.DBG("New %s '%s' Size:%d", otyp, finfo.fpath, finfo.FSize)
	me.member[fhash] = finfo

	return
}

func (me *FileInfo) open() (err error) {
	me.fo, err = os.Open(me.fpath)
	if err != nil {
		err = fmt.Errorf("open.Open>%v", err)
		return
	}

	return
}

// func (me *FileInfo) create(fname string, Mode fs.FileMode) (err error) {
// 	if err = me.init(fname); err != nil {
// 		err = fmt.Errorf("create>%v", err)
// 		return
// 	}
// 	if me.initialized {
// 		err = fmt.Errorf("file is exist")
// 		return
// 	}

// 	me.fo, err = os.OpenFile(fname, os.O_CREATE|os.O_WRONLY, Mode)
// 	if err != nil {
// 		err = fmt.Errorf("create>%v", err)
// 		return
// 	}

// 	return
// }

// //init the struct after instantiate;
// //nil and initialized is false: file not exist
// //exist: success and initialized is true
// func (me *FileInfo) init(fname string) (err error) {
// 	me.initialized = false
// 	me.fi, err = os.Stat(fname)
// 	if os.IsNotExist(err) {
// 		err = nil
// 	}
// 	if err != nil {
// 		err = fmt.Errorf("init>%v", err)
// 	} else {
// 		me.initialized = true
// 	}

// 	return
// }
