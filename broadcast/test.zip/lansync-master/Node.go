package lansync

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"io"
	"math/rand"
	"net"
	"os"
	"regexp"
	"strings"
	"syscall"
	"time"
	"unsafe"

	"golang.org/x/sys/unix"
)

type Node struct {
	Server    *net.UDPAddr
	ServerIs  bool
	lastClaim time.Time

	NoId     uint16
	listenok chan int
	//
	rgxExcl  *regexp.Regexp
	scanival int

	Root *FileInfo

	//if wd!=0 then it is already watched
	fd     int
	poller *fdPoller
	// watch  map[int]*dirinfo
	watch map[int]*FileInfo
	// watch_ sync.Mutex

	// Channel for sending a "quit message" to the reader goroutine
	done chan struct{}
	// Channel for sending a "quit resp" to the reader goroutine
	doneResp chan struct{}
	//channel for event
	mfc chan *FileInfo

	NewBcastFile bool
	NewBcastOfs  int
	NewBcast     [PKTMaxPayload]byte

	uc []*udpcomm

	Tcp *TcpFile
	// finbuf *bytes.Buffer

}

// starts as candidate of Server
// in a network, it will have some candidate
func (me *Node) Serv(nconn int) (err error) {
	L.INF("Starts the BcastNode as Candidate!")
	return me.start(nconn, true)
}

// starts as Peer
func (me *Node) Sync(nconn int) (err error) {
	L.INF("Starts the BcastNode as PeerMember!")
	return me.start(nconn, false)
}

/*
Starts the apps, listen on :port,
and if it's a Candidate, then trying to become Server
nconn tells number of udpcomm spawns
*/
func (me *Node) start(nconn int, Candidate bool) (err error) {
	var uc *udpcomm

	for i := 0; i < nconn; i++ {
		L.DBG("Create a new UdpComm:%i", i)
		uc, err = NewUdpComm(
			me,
			&net.UDPAddr{
				IP:   net.IPv4(0, 0, 0, 0),
				Port: SERVER_PORT + i,
			},
		)
		if err != nil {
			err = fmt.Errorf("start.newudp(%d)>%v", i, err)
			return
		}

		uc.Id = i
		if i == 0 {
			uc.MGICList = []uint16{MGICBC_NOTIFY, MGICSV_FILEINFO}
		} else {
			uc.MGICList = []uint16{MGICSV_DATABLOK, MGICBC_FEEDBACK}
		}
		me.uc = append(me.uc, uc)
		go me.listener(me.uc[i])

		<-me.listenok
	}

	//wait for about 1s up to 4s before start
	L.DBG("Joining the Network...")
	rand.Seed(time.Now().Unix())
	wait := time.Duration(rand.Float64()*3000) + 1 //1 up to 4s
	time.Sleep(wait * time.Millisecond)

	//at first, trying to ask the network who is the Server right now?
	me.lastClaim = time.Now()

	//in a network, there should be a server ready to serve.
	//every node should ask who is the server, since the server is the central
	//broadcast message:
	//1. ask who is the server in charge
	//2. server command and data
	//
	//every peernode should only send private message to server,
	//except point 1 above.

	//wait for the response from Server
	resend := 3
	pkttype := CMD_WHOISTHESERVER
	L.DBG("Send Who Is The Server %ix", resend)

	for resend > 0 { //3 times in a row
		err = me.SendPkt(MGICBC_NOTIFY, pkttype, nil)
		if err != nil {
			err = fmt.Errorf("start.notify:%0X>%v", pkttype, err)
			return
		}
		time.Sleep(10 * time.Millisecond)
		resend--
	}
	time.Sleep(300 * time.Millisecond)

	if me.Server != nil { //peer
		//if there is already a Server, NodeType would become MEMBER
		return //Client just being passive and waiting from the daemon
	}
	if !Candidate { //no Server replying, try to become one.
		err = fmt.Errorf("no master, and not a candidate")
		return
	}
	pkttype = CMD_IAMTHESERVER
	resend = 3
	L.DBG("Send 'I am The Server' %ix", resend)

	for resend > 0 { //3 times in a row
		err = me.SendPkt(MGICBC_NOTIFY, pkttype, nil)
		if err != nil {
			err = fmt.Errorf("start.notify:%0X>%v", pkttype, err)
			return
		}
		time.Sleep(10 * time.Millisecond)
		resend--
	}
	time.Sleep(300 * time.Millisecond)

	L.DBG("Server: %v", me.Server)
	//after challenge, we will understand who really is the provider this time

	if !me.ServerIs { //if not serv, then exit right now.
		err = fmt.Errorf("can't claim as master")
		return
	}

	/*
		When a node first joining to the network, it needs to know who is the
		Server. By broadcasting 'who is the Server', in the hope the Server would
		eventually answers.
		if none of the Server answers in 100ms, then in the random delay (100-300ms)
		some candidates, will try to step up as the Server.
		the first one succeesfully accepted by others, it will be admitted as the Server
	*/
	// //just another wait...
	// time.Sleep(TICKS_WAITSERVERNOTE * time.Millisecond)
	// if me.Server == nil {
	// 	err = fmt.Errorf("none is Server")
	// 	L.ERR(err, "Fail to get Server")
	// 	return
	// }

	// Create inotify fd
	me.fd, err = unix.InotifyInit1(unix.IN_CLOEXEC)
	if me.fd == -1 || err != nil {
		err = fmt.Errorf("inotifyinit>%v", err)
		return
	}

	// Create epoll
	me.poller, err = newFdPoller(me.fd)
	if err != nil {
		unix.Close(me.fd)
		err = fmt.Errorf("newfilescan>%v", err)
		return
	}

	//spawns an events
	go me.inotifyEvents()

	//
	if err = me.Root.scan(); err != nil {
		err = fmt.Errorf("start>%v", err)
		L.ERR(err, "root scan")
		return
	}

	L.INF("Server Successfully Started.")

	// //create tcp listener
	// TCPL, err := net.ListenTCP("tcp", (*net.TCPAddr)(me.Server))
	// if err != nil {
	// 	L.ERR(err, "listen TCP (%s)", me.Server.String())
	// 	return
	// }
	// go me.TCPServer(TCPL)

	me.Tcp = new(TcpFile)
	go me.Tcp.Server((*net.TCPAddr)(me.Server))

	return
}

// Remove stops watching the named file or directory (non-recursively).
// whatever happen not returning result, check log!
func (me *Node) Remove(wd int) {
	// inotify_rm_watch will return EINVAL if the file has been deleted;
	// the inotify will already have been removed.
	// watches and pathes are deleted in ignoreLinux() implicitly and asynchronously
	// by calling inotify_rm_watch() below. e.g. readEvents() goroutine receives IN_IGNORE
	// so that EINVAL means that the wd is being rm_watch()ed or its file removed
	// by another thread and we have not received IN_IGNORE event.
	success, err := unix.InotifyRmWatch(me.fd, uint32(wd))
	if err != nil {
		L.ERR(err, "Remove Inotify")

	} else {
		L.INF("Remove Inotify, succ:%d", success)
	}

	// We successfully removed the watch if InotifyRmWatch doesn't return an
	// error, we need to clean up our internal state to ensure it matches
	// inotify's kernel state.
	// delete(me.paths, int(watch.wd))
	// delete(me.watches, name)

	// if success == -1 {
	// 	// TODO: Perhaps it's not helpful to return an error here in every case.
	// 	// the only two possible errors are:
	// 	// EBADF, which happens when w.fd is not a valid file descriptor of any kind.
	// 	// EINVAL, which is when fd is not an inotify descriptor or wd is not a valid watch descriptor.
	// 	// Watch descriptors are invalidated when they are removed explicitly or implicitly;
	// 	// explicitly by inotify_rm_watch, implicitly when the file they are watching is deleted.
	// 	return errno
	// }
}

/*
SendPkt:
*/
func (me *Node) SendPkt(MGIC uint16,
	CMD byte, load interface{}) (err error) {
	var uc *udpcomm

	bi := new(bytes.Buffer)
	binary.Write(bi, binary.BigEndian, MGIC)
	binary.Write(bi, binary.BigEndian, me.NoId)
	binary.Write(bi, binary.BigEndian, CMD)

	switch MGIC {
	case MGICBC_NOTIFY: //notify is not countint the size
		uc = me.uc[0]
		// binary.Write(bi, binary.BigEndian, byte(0))

	case MGICSV_FILEINFO:
		uc = me.uc[0]
		//send a file header
		files := (load).(*[]*FileInfo)
		//the seq pos filled with number of files
		binary.Write(bi, binary.BigEndian, byte(len(*files)))
		for _, file := range *files {
			binary.Write(bi, binary.BigEndian, (*file).FInfo)
		}

	case MGICBC_FEEDBACK:
		uc = me.uc[0]

	// case MGICSV_DATABLOK:
	// 	uc = me.uc[1]
	default:
		return fmt.Errorf("***")
	}

	uc.Lock()
	_, err = uc.conn.WriteToUDP(
		bi.Bytes(),
		&net.UDPAddr{
			IP:   net.IP{0xFF, 0xFF, 0xFF, 0xFF},
			Port: uc.laddr.Port,
		},
	)
	uc.Unlock()
	if err != nil {
		err = fmt.Errorf("sendpkt.writeudp>%v", err)
	}

	return
}

// inotifyEvents reads from the inotify file descriptor, converts the
// received events into Event objects and sends them via the Events channel
func (me *Node) inotifyEvents() {
	var buf [MAX_EVENBUF]byte
	var n int
	var name string
	var offset, mask, nameLen uint32
	var rawEvent *unix.InotifyEvent
	var fdir, finfo *FileInfo
	finfos := make([]*FileInfo, MAX_PKTFINFO)
	findx := 0

	defer func() {
		L.INF("End of Inotify Events")
		close(me.doneResp)
		unix.Close(me.fd)
		me.poller.close()
	}()

	for {
		// See if we have been closed.
		if me.isClosed() {
			return
		}

		ok, err := me.poller.wait()
		if err != nil {
			L.ERR(err, "Poller.wait")
			return
		}
		if !ok {
			L.INF("Poller.wait")
			continue
		}

		n, err = unix.Read(me.fd, buf[:])
		// If a signal interrupted execution, see if we've been asked to close,
		//and try again. http://man7.org/linux/man-pages/man7/signal.7.html:
		// "Before Linux 3.8, reads from an inotify(7) file descriptor were not restartable"
		if err == unix.EINTR {
			L.ERR(err, "unix.read")
			continue
		}

		// unix.Read might have been woken up by Close. If so, we're done.
		if me.isClosed() {
			return
		}

		if n < unix.SizeofInotifyEvent {
			if n == 0 {
				// If EOF is received. This should really never happen.
				err = io.EOF
			} else {
				// Read was too short.
				err = fmt.Errorf("unixread_premature(%db)>%v", n, err)
			}
			L.ERR(err, "premature read!")
			continue
		}

		// We don't know how many events we just read into the buffer
		// While the offset points to at least one whole event...
		offset = 0
		for offset <= uint32(n-unix.SizeofInotifyEvent) {
			// Point "rawEvent" to the event in the buffer
			rawEvent = (*unix.InotifyEvent)(unsafe.Pointer(&buf[offset]))
			mask = uint32(rawEvent.Mask)
			nameLen = uint32(rawEvent.Len)
			bufofs := offset
			offset += unix.SizeofInotifyEvent + nameLen

			if mask&unix.IN_Q_OVERFLOW != 0 {
				err = fmt.Errorf("inotifyoverflow")
				L.ERR(err, "ReadEvent")
				continue
			}

			// If the event happened to the watched directory or the watched file,
			// the kernel doesn't append the filename to the event, but we would
			// like to always fill the "Name" field with a valid filename.
			//We retrieve the path of the watch from the "paths" map.
			// me.watch_.Lock()
			fdir, ok = me.watch[int(rawEvent.Wd)]
			// me.watch_.Unlock()
			if !ok { //the watch description is not found, ignore it.
				err = fmt.Errorf("me.watch entry not exist")
				L.ERR(err, "watchdescriptor:%d !found", rawEvent.Wd)
				continue
			}

			if nameLen > 0 {
				// Point "bytes" at the first byte of the filename
				// bytes := (*[unix.PathMax]byte)(unsafe.Pointer(&buf[offset+unix.SizeofInotifyEvent]))[:nameLen:nameLen]
				bytes := (*[unix.PathMax]byte)(unsafe.Pointer(&buf[bufofs+unix.SizeofInotifyEvent]))[:nameLen]
				// The filename is padded with NULL bytes. TrimRight() gets rid of those.
				name = strings.TrimRight(string(bytes), "\000")
			}

			// Ignore anything the inotify API says to ignore
			if mask&unix.IN_IGNORED > 0 { //IN_IGNORE == 0x8000
				// L.DBG("ask to ignore name:%s mask:%X", name, mask)
				continue
			}

			if mask&unix.IN_DELETE_SELF > 0 {
				//delete self is ignore since there will be another event
				L.INF("DELSELF: '%s' name:'%s/%s' mask:%X, Wd:%d",
					fdir.fpath,
					name,
					fdir.Fname,
					mask,
					rawEvent.Wd,
				)
				continue
			}

			if name[0] == '.' || name[len(name)-1] == '~' {
				// L.DBG("File start with . OR end with ~ is ignored name:'%s'", name)
				continue
			}

			// L.DBG("Ofs:%d mask:%X WDir:%d fpath:'%s' fname:'%s'/'%s'",
			// 	offset,
			// 	mask,
			// 	rawEvent.Wd,
			// 	fdir.Fname,
			// 	fdir.fpath,
			// 	name,
			// )

			NEWFILE := mask&(unix.IN_CREATE|unix.IN_MOVED_TO) != 0
			DELRENCMD := mask&(unix.IN_DELETE_SELF|unix.IN_DELETE|unix.IN_MOVE_SELF|unix.IN_MOVED_FROM) != 0

			finfo, ok = fdir.member[mHash(name)]
			if !ok {
				if !NEWFILE {
					//not create andnot move
					//mask is not sync with the FileInfo
					//FileInfo tells there are no member,
					//but mask tell it is not a new file
					L.ERR(
						fmt.Errorf("notanewfile"),
						"member not found, but not a new file; mask:%X",
						mask,
					)
					continue
				}
				finfo = fdir.new(name)
				if finfo == nil {
					L.INF("fdir:%s fail to new:%s",
						fdir.Fname,
						name,
					)
					continue
				}
				if !finfo.Isdir {
					//there will be 2 event on every New File, whether new and chmod or new and write
					//therefore we ignore new event, to supress only 1 event
					continue
				}
				//new directory
				wd, err := unix.InotifyAddWatch(
					me.fd,
					finfo.fpath,
					agnosticEvents,
				)
				if wd == -1 || err != nil {
					err = fmt.Errorf("scan(%s)>%v", finfo.fpath, err)
					L.ERR(err, "AddWatch")
					continue
				}
				L.DBG("New Watch:%d Dir:%s", wd, finfo.fpath)
				me.watch[wd] = finfo

			} else {

				// DELRENCMD := mask & (unix.IN_DELETE_SELF |
				// 	unix.IN_DELETE |
				// 	unix.IN_MOVE_SELF |
				// 	unix.IN_MOVED_FROM)

				// If the event is not a DELETE or RENAME, the file must exist.
				// Otherwise the event is ignored.
				// *Note*: this was put in place because it was seen that a MODIFY
				// event was sent after the DELETE. This ignores that MODIFY and
				// assumes a DELETE will come or has come if the file doesn't exist.
				fi, err := os.Stat(finfo.fpath)
				// if finfo.Op&^(FDELETE|FRENAME) != 0 {
				if !DELRENCMD { //not a delete command
					if os.IsNotExist(err) {
						L.ERR(
							err,
							"File:'%s' not found! Op:%s",
							finfo.fpath, Ops[finfo.Op],
						)
						continue
					}

					finfo.UmodTime = fi.ModTime().Unix()
					finfo.FSize = fi.Size()
					finfo.Mode = uint32(fi.Mode())
					ugid := fi.Sys().(*syscall.Stat_t)
					finfo.Uid = ugid.Uid
					finfo.Gid = ugid.Gid

					switch {
					case mask&unix.IN_MODIFY > 0:
						finfo.Op = FWRITE

					case mask&unix.IN_ATTRIB > 0:
						finfo.Op = FCHMOD

					default:
						L.ERR(fmt.Errorf("Mask:%X", mask), "mask is beyond control")
						finfo.Op = 0
					}

				} else {
					switch {
					case mask&unix.IN_DELETE_SELF > 0:
						finfo.Op = FDELETE

						// IN_DELETE_SELF occurs when the file/directory
						// being watched is removed. This is a sign to clean up the maps,
						// otherwise we are no longer in sync with the inotify kernel
						// state which has already deleted the watch automatically.
						// me.watch_.Lock()
						delete(me.watch, int(rawEvent.Wd))
						// me.watch_.Unlock()
						L.DBG("me.watch delete key:%s", fdir.Fname)

						fhash := fdir.fhash
						fdir = fdir.parent
						delete(fdir.member, fhash)
						L.DBG("Delete Map fdir, member:%X", fhash)

					case mask&unix.IN_DELETE > 0:
						finfo.Op = FDELETE
						delete(fdir.member, finfo.fhash)
						L.DBG("Delete Map fdir, member:%X", finfo.fhash)

					case mask&(unix.IN_MOVE_SELF|unix.IN_MOVED_FROM) > 0:
						finfo.Op = FRENAME
					}

				}
			}
			L.DBG("mask:%08X rawEvent:%d Op:%s NPath:'%s' hash:%X/%X",
				mask,
				int(rawEvent.Wd),
				Ops[finfo.Op],
				finfo.fpath, //fpath is already included name
				finfo.phash,
				finfo.fhash,
			)
			me.mfc <- finfo
		}

		// Send the events that are not ignored on the events channel
		for finfo = range me.mfc {
			finfos[findx] = finfo
			findx++
			if findx == MAX_PKTFINFO {
				break
			}
			// finfos = append(finfos, *finfo)
			// if me.finbuf == nil {
			// 	me.finbuf = new(bytes.Buffer)
			// }
			// err = finfo.bpack(me.finbuf)
			// if err != nil {
			// 	L.ERR(err, "bpack")
			// 	continue
			// }

			var info string
			if finfo.Mode&FMODE_DIR > 0 {
				info = "Dirs"
			} else {
				info = "File"
			}
			L.INF("%s %s %08X/%08X; Name:%s; %v (%d)",
				Ops[finfo.Op],
				info,
				finfo.phash, finfo.fhash,
				finfo.Fname,
				time.Unix(finfo.UmodTime, 0),
				finfo.FSize,
			)

		}

	}
}

func (me *Node) PullFile(dst, src string) (err error) {
	return me.Xchgfile(true, dst, src)
}

func (me *Node) PushFile(src, dst string) (err error) {
	return me.Xchgfile(false, dst, src)
}

// both src and dst max length is 128 bytes
// both src and dst has relative path
func (me *Node) Xchgfile(pull bool, dst, src string) (err error) {
	var t *net.TCPConn
	var raddr *net.TCPAddr

	//make a connection
	raddr, _ = net.ResolveTCPAddr("tcp", me.Server.String())
	t, err = net.DialTCP("tcp", nil, raddr)
	if err != nil {
		err = fmt.Errorf("dialtcp>%v", err)
		return
	}

	hdr := new(TcpFile)
	hdr.bbyte = make([]byte, TRF_MAXPACKET)

	if dst[len(dst)-1] == '/' {
		tokens := strings.Split(src, "/")
		dst += tokens[len(tokens)-1]
	}

	L.DBG("Xchgfile from: '%s' to '%s'", src, dst)
	hdr.Err = ""
	hdr.Src = src
	hdr.Dst = dst
	hdr.t = t
	if pull {
		hdr.stat = TRSTAT_MODEPULL
	} else {
		hdr.stat = TRSTAT_MODEPUSH
	}
	hdr.proceed(false) //atclient then false

	return
}

// this is an example of peeking the content of the channel
func (me *Node) isClosed() bool {
	select {
	case <-me.done:
		return true
	default:
		return false
	}
}

// Close removes all watches and closes the events channel.
func (me *Node) Close() error {
	if me.isClosed() {
		return nil
	}

	// Send 'close' signal to goroutine, and set the Watcher to closed.
	close(me.done)

	// Wake up goroutine
	me.poller.wake()

	// Wait for goroutine to close
	<-me.doneResp

	return nil
}
