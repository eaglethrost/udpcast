package lansync

import (
	"hash/crc32"
	"io/fs"
	"os"

	"golang.org/x/sys/unix"
)

const (
	PKTMaxPayload   = PKTMaxLength - 16 //header
	NUMPAGEPERBLOCK = 64
	PAGEBLOCKSIZE   = PKTMaxPayload * NUMPAGEPERBLOCK
)

const (
	BC_CHECKINTERVAL   = 60
	MAX_MODTIME        = 120 //in seconds
	NODETYPE_MEMBER    = 0
	NODETYPE_CANDIDATE = 1
	NODETYPE_SERVER    = 2
)

const (
	FCREATE uint32 = 1 << iota
	FWRITE
	FDELETE
	FRENAME
	FSCANNED
	FUPDATED
	FCHMOD
)

const (
	MAX_EVENBUF   int    = unix.SizeofInotifyEvent * 4096
	MAX_CHUNKSIZE int    = 64 * PKTMaxLength
	FMODE_DIR     uint32 = 1 << 31

	agnosticEvents uint32 = unix.IN_MOVED_TO |
		unix.IN_MOVED_FROM |
		unix.IN_CREATE |
		unix.IN_ATTRIB |
		unix.IN_MODIFY |
		unix.IN_MOVE_SELF |
		unix.IN_DELETE |
		unix.IN_DELETE_SELF

	IN_ALL_EVENTS = unix.IN_ACCESS |
		unix.IN_MODIFY | unix.IN_ATTRIB |
		unix.IN_CLOSE_WRITE |
		unix.IN_CLOSE_NOWRITE |
		unix.IN_OPEN |
		unix.IN_MOVED_FROM |
		unix.IN_MOVED_TO |
		unix.IN_DELETE |
		unix.IN_CREATE |
		unix.IN_DELETE_SELF
)

var Ops = map[uint32]string{
	0:        "NONE",
	FCREATE:  "CREATE",
	FWRITE:   "WRITE",
	FDELETE:  "DELETE",
	FRENAME:  "RENAME",
	FSCANNED: "SCANNED",
	FUPDATED: "UPDATED",
	FCHMOD:   "CHMOD",
}

const (
	PKTMaxLength = 1444

	//for sending announcement, single packet only.
	MGICBC_NOTIFY   uint16 = 0xB0B0
	MGICSV_FILEINFO uint16 = 0xF16E
	MGICSV_DATABLOK uint16 = 0xDA7A
	MGICBC_FEEDBACK uint16 = 0xFEED
	MGICFB_JOIN     uint16 = 0x7012

	CMD_FILE_NEW byte = iota + 1
	CMD_FILE_UPDATE
	CMD_FILE_DELETE
	CMD_JOIN_XX1
	CMD_JOIN_XX2
	CMD_DATABLOK_
	CMD_FEEDBACK_

	MFCFROM_1 = 1
	MFCFROM_2 = 2

	//in millisec, wait for master give notification.
	TICKS_WAITSERVERNOTE   = 1000
	TICKS_WAITSERVERVOTE   = 1000
	TICKS_FILESCAN         = 300000 //5 minutes
	TICKS_DELAYSERVERCLAIM = 20000  //reclaim should more than 2s
)

const (
	CMDMASKPKTTYPE_         = 0xC0 //use only 2 left bit
	CMDMASKPKTTYPE_HDRONLY  = 0x00
	CMDMASKPKTTYPE_HDRPARAM = 0x40
	CMDMASKPKTTYPE_PAYLOAD  = 0x80
	CMDMASKPKTTYPE_ENCRYPT  = 0xC0
)

const (
	//max 127 type of command
	CMD_WHOISTHESERVER byte = iota + 1
	CMD_IAMTHESERVER
	//

	MASK_BCASTCMD_REQ byte = 0xF0
	// MASK_BCASTCMD_RSP byte = 0x0F
	PKTHSZ = 18 //size of the packet header
)

var cmds = map[byte]string{
	CMD_WHOISTHESERVER: "Who Is The Server",
	CMD_IAMTHESERVER:   "I am The Server",
	CMD_FILE_UPDATE:    "FILE UPDATE",
}

var CRC32T = crc32.MakeTable(0xD5828281) //global var

type FileInfo struct {
	Node   *Node
	parent *FileInfo
	fo     *os.File
	fi     fs.FileInfo
	Op     uint32
	member map[uint32]*FileInfo
	Fname,
	fpath string
	phash,
	fhash uint32
	FInfo //interchangeable vars
}

type FInfo struct {
	Isdir     bool
	UmodTime, //timestamp in unix
	FSize int64
	Mode,
	Crc32,
	Uid,
	Gid uint32
}

const (
	PKTCMD_NEWFILE byte = iota + 1 //a new object
	PKTCMD_GETNAME
)

const (
	SERVER_PORT  = 5000
	MAX_PKTFINFO = 10
)
