package lansync

import (
	"bytes"
	"compress/gzip"
	"encoding/binary"
	"encoding/gob"
	"fmt"
	"io"
	"io/fs"
	"net"
	"os"
)

const (
	TRF_MAXPACKET = 131072 //128KB
	// TRFNET_GET    uint16 = 0x1111
	// TRFNET_PUT    uint16 = 0x2222

	//bitwise
	TRFLAG_CONTROL  uint8 = 0b00000001 //unless it is data
	TRFLAG_ENCRYPT  uint8 = 0b00000010 //unless it is plain
	TRFLAG_COMPRESS uint8 = 0b00000100 //unless it is uncompress
	TRFLAG_1XXX1    uint8 = 0b00001000 //unless it is a data
	//
	// TRSTAT_MASK     uint8 = 0b01110000
	TRSTAT_READY     uint8 = 0b00000000
	TRSTAT_ACK       uint8 = 0b00010000
	TRSTAT_MODEPULL  uint8 = 0b00100000
	TRSTAT_MODEPUSH  uint8 = 0b00110000
	TRSTAT_ENDOFFILE uint8 = 0b01000000
	TRSTAT_2ACK      uint8 = 0b01010000
	TRSTAT_2PULL     uint8 = 0b01100000
	TRSTAT_2PUSH     uint8 = 0b01110000
	//
	TRERR_MASK        uint8 = 0b10000000
	TRERR_FNOTEXIST   uint8 = 0b10000000
	TRERR_FOPENFAIL   uint8 = 0b10010000
	TRERR_FCREATEFAIL uint8 = 0b10100000
	TRERR_FREADFAIL   uint8 = 0b10110000
	TRERR_FWRITEFAIL  uint8 = 0b11000000
	// TRERR_ENDOFFILE   uint8 = 0b11010000
	TRERR_FZIPFAIL  uint8 = 0b11100000
	TRERR_GOBENCODE uint8 = 0b11110000
)

type TcpFile struct {
	// Magic uint16
	Fmode uint32
	Fsize,
	Ftime int64
	Src,
	Dst,
	Err string
	//
	bbyte []byte
	//
	stat uint8
	encrypt,
	compress,
	control bool
	//
	t  *net.TCPConn
	fo *os.File
	getofs,
	setofs int
}

// func (me *TcpFile) pack() (p []byte) {
func (me *TcpFile) pack() (wlen int, err error) {
	w := &bytes.Buffer{}
	binary.Write(w, binary.BigEndian, uint32(0))
	err = gob.NewEncoder(w).Encode(me)
	if err != nil {
		L.ERR(err, "gob.encode")
		me.stat = TRERR_GOBENCODE
		me.Err = fmt.Sprintf("gob.encode>%v", err)

	} else {
		bb := w.Bytes() //include the 4 bytes prepend
		copy(me.bbyte, bb)
		me.control = true
	}

	wlen, err = me.netsend(w.Len())
	return
}

func (me *TcpFile) unpack(p []byte) (err error) {
	return gob.NewDecoder(bytes.NewReader(p)).Decode(me)
}

func (me *TcpFile) Server(Saddr *net.TCPAddr) (err error) {
	var tcpconn *net.TCPConn
	//create tcp listener
	tcpl, err := net.ListenTCP("tcp", Saddr)
	if err != nil {
		L.ERR(err, "listen TCP (%s)", Saddr.String())
		return
	}

relisten:
	for {
		tcpconn, err = tcpl.AcceptTCP()
		L.DBG("Get a client, from:%v", tcpconn.RemoteAddr())
		if err != nil {
			L.ERR(err, "accept")
			return
		}

		thdr := new(TcpFile)
		thdr.t = tcpconn
		thdr.bbyte = make([]byte, TRF_MAXPACKET)
		// L.DBG("me.bbyte:%d", len(thdr.bbyte))

		if _, err = thdr.netrecv("Server"); err != nil {
			L.ERR(err, "netread")
			goto relisten
		}

		if thdr.stat&TRERR_MASK != 0 {
			L.WRN("remote is not ready, cancel the transfer")
			goto relisten
		}

		go thdr.proceed(true)
	}
}

func (me *TcpFile) proceed(isServer bool) {
	var err error
	var Finfo fs.FileInfo
	var rlen int
	me.getofs = 0
	me.setofs = 0

	mget := me.stat == TRSTAT_MODEPULL
	// var mode string
	// if mget {
	// 	mode = "Get"
	// } else {
	// 	mode = "Put"
	// }

	defer func() {
		me.t.Close()
		me.fo.Close()
		if mget != isServer { //this is !XOR logic
			// os.Rename(Fdst, utils.ArrtoStr(me.Fdst[:]))
			os.Rename(me.Dst+".tmp", me.Dst)
		}
	}()

	dom := "Client"
	if isServer {
		dom = "Server"
	}

	if mget == isServer { //this is XOR logic
		Finfo, err = os.Stat(me.Src)
		if err != nil && os.IsNotExist(err) {
			//if the file is not exist while trying to get it, then it is an error
			L.ERR(err, "filenotexist:%s", me.Src)
			me.Err = fmt.Sprintf("file %s not exist!", me.Src)
			me.Src = ""
			me.stat = TRERR_FNOTEXIST

		} else {
			me.Fmode = uint32(Finfo.Mode())
			me.Fsize = Finfo.Size()
			me.Ftime = Finfo.ModTime().Unix()
			me.compress = true //first try
			me.fo, err = os.Open(me.Src)
			if err != nil {
				L.ERR(err, "open:%s fail", me.Src)
				me.Err = fmt.Sprintf("open '%s' failed>%v", me.Src, err)
				me.Src = ""
				me.stat = TRERR_FOPENFAIL
			}
		}

	} else {
		_, err = os.Stat(me.Dst + ".tmp")
		if err == nil {
			//file is there, perhaps continuation of last process.
			L.INF("%s fileexist:'%s'", dom, me.Dst+".tmp")
			// me.Fsize = Finfo.Size()
		}

		me.fo, err = os.OpenFile(
			me.Dst+".tmp",
			os.O_RDWR|os.O_CREATE,
			0644, //temporary
		)
		if err != nil {
			L.ERR(err, "create '%s' fail", me.Dst+".tmp")
			me.Err = fmt.Sprintf("create '%s' failed>%v", me.Dst+".tmp", err)
			me.Dst = ""
			me.stat = TRERR_FCREATEFAIL
		} else {
			me.Fsize, _ = me.fo.Seek(0, 2) //seek to the end
		}
	}

	//send the 1st packet from each side (client and server)
	//server's packet is the response's client
	// L.DBG("2 %s stat:%s %d", dom, mode, me.stat)
	rlen, err = me.pack() //send included
	if err != nil {
		L.ERR(err, "pack size:%s", rlen)
		return
	}

	if me.stat&TRERR_MASK != 0 { //local status
		L.WRN("%s we are not ready, cancel. stat:%b", dom, me.stat)
		return
	}

	if mget != isServer {
		rlen, err = me.netrecv(dom)
		if err != nil {
			L.ERR(err, "netread")
			return
		}
		//the caller side will get the respon from server
		L.DBG("%s get the reply: (%d)", dom, rlen)
		if me.stat&TRERR_MASK != 0 {
			L.WRN("%s ack that remote cancels. msg:%s.",
				dom, me.Err)
			return
		}
	}

	L.DBG("%s START FILE TRANSFER ***", dom)
	for {
		if mget == isServer {
			me.fileread(dom)
			if me.stat == TRSTAT_ENDOFFILE {
				L.INF("file reading has reach an end: '%s'", me.Src)
				break
			}

			if me.stat&TRERR_MASK != 0 {
				L.WRN("file.read '%s'", me.Src)
				break
			}

			_, err = me.netrecv(dom)
			if err != nil {
				L.ERR(err, "%s net.ack msg:'%s'", dom, me.Err)
				break
			}

			if me.stat == TRSTAT_ACK {
				continue
			}

		} else {
			_, err = me.netrecv(dom)
			if err != nil {
				L.ERR(err, "%s tcp.read %d/%d byte",
					dom, me.setofs, me.Fsize)
				return
			}

			if me.stat == TRSTAT_ENDOFFILE {
				L.INF("file writing finished '%s'", me.Dst)
				err = os.Chmod(me.Dst+".tmp",
					fs.FileMode(me.Fmode))
				if err != nil {
					L.ERR(err, "fail change mode: %s", me.Dst+".tmp")
				}

				break
			}
		}
	}
}

// a tcp read routine
func (me *TcpFile) netrecv(dom string) (rlen int, err error) {
	var rl, pktlen int
	var gwr *gzip.Reader
	var xbyte []byte
	var ll uint32

	rlen = 0
	if rlen < 4 {
		rl, err = me.t.Read(me.bbyte[rlen:4])
		if err != nil {
			err = fmt.Errorf("tcpread1>%v", err)
			return
		}
		rlen += rl
	}
	ll = binary.BigEndian.Uint32(me.bbyte)
	pktlen = int(ll & 0x00FFFFFF)
	pflag := uint8(ll >> 24)

	me.encrypt = pflag&TRFLAG_ENCRYPT != 0
	me.compress = pflag&TRFLAG_COMPRESS != 0
	me.control = pflag&TRFLAG_CONTROL != 0
	me.stat = pflag & 0xF0
	me.setofs += rlen

	// L.DBG("Stat:%b %x pflag:%b", me.stat, me.bbyte[:4], pflag)
	if me.stat == TRSTAT_ENDOFFILE {
		L.INF("net.read reach end of file")
		rlen = 0
		return
	}

	for rlen < pktlen {
		rl, err = me.t.Read(me.bbyte[rlen:pktlen])
		if err != nil {
			err = fmt.Errorf("tcpread2>%v", err)
			return
		}
		rlen += rl
	}

	// if me.encrypt {
	// 	//try to decrypt it
	// }

	if me.control {
		err = me.unpack(me.bbyte[4:rlen])
		if err != nil {
			err = fmt.Errorf("unpack>%v", err)
		}
		return
	}

	if me.compress {
		// if me.bbyte[4] == 0x1F && me.bbyte[5] == 0x8B {
		//decompress it
		gwr, err = gzip.NewReader(bytes.NewReader(me.bbyte[4:rlen]))
		if err != nil {
			err = fmt.Errorf("gzip.newreader>%v", err)
			return
		}
		xbyte, err = io.ReadAll(gwr) //the same return value
		if err != nil {
			err = fmt.Errorf("io.readall rlen:%d >%v", rlen, err)
			return
		}
		copy(me.bbyte[4:], xbyte)
		rlen = len(xbyte) + 4
		// }

	}

	//file write it
	rlen, err = me.fo.Write(me.bbyte[4:rlen])
	me.setofs += rlen
	if err != nil {
		L.ERR(err, "file.write %d bytes", rlen)
		me.stat = TRERR_FWRITEFAIL
		me.Err = fmt.Sprintf("file.write>%s", err)

	} else {
		L.DBG("%s file.write %d/%d %d",
			dom, rlen, me.setofs, me.Fsize)
		me.stat = TRSTAT_ACK
	}

	me.pack() //send is included
	return
}

func (me *TcpFile) fileread(dom string) (rlen int, err error) {
	buf := &bytes.Buffer{}
	grd := gzip.NewWriter(buf)

	rlen, err = me.fo.Read(me.bbyte[4:]) //read until empty then show EOF
	olen := rlen
	me.getofs += olen
	me.control = false //is not a control
	if err == io.EOF || rlen == 0 {
		me.stat = TRSTAT_ENDOFFILE
		copy(me.bbyte, []byte{0, 0, 0, 0})
		err = nil //not considered as error
		rlen = 0

	} else if err != nil {
		me.stat = TRERR_FREADFAIL
		me.Err = fmt.Sprintf("file.read>%v", err)
		me.pack()
		return

	} else {
		// me.stat = TRSTAT_READY
		if me.compress {
			// zip it
			grd.Reset(buf)
			_, err = grd.Write(me.bbyte[4:])
			if err == nil {
				err = grd.Close()
			}
			// L.DBG("gzip orig:%d comp:%d", rlen, buf.Len())
			//trap 2 err in single action
			if err != nil {
				me.stat = TRERR_FZIPFAIL
				me.Err = fmt.Sprintf("zip.write>%v", err)
				me.pack() //send is included
				return

			} else if buf.Len() < rlen-(rlen/7) {
				copy(me.bbyte[4:], buf.Bytes())
				rlen = buf.Len()
			} else {
				me.compress = false
			}
		}
	}

	if !me.control {
		L.DBG("%s fileread: %d %d/%d byte",
			dom, olen, me.getofs, me.Fsize)
	}
	rlen, err = me.netsend(rlen + 4)

	return
}

func (me *TcpFile) netsend(size int) (wlen int, err error) {

	pflag := me.stat

	if me.encrypt {
		pflag |= TRFLAG_ENCRYPT
	}
	if me.compress {
		pflag |= TRFLAG_COMPRESS
	}
	if me.control {
		pflag |= TRFLAG_CONTROL
	}
	// L.DBG("me.bbyte:%d stat:%x", size, me.stat)

	binary.BigEndian.PutUint32(me.bbyte, uint32(size))
	me.bbyte[0] |= pflag

	wlen, err = me.t.Write(me.bbyte[:size])
	// L.DBG("Stat:%b %x", me.stat, me.bbyte[:10])

	return
}
