package lansync

import (
	"fmt"
	"hash/crc32"
	"io"
	"math/rand"
	"net"
	"os"
	"regexp"
	"strings"
	"time"

	"equnix.asia/libs/utils"
)

var L *utils.Log = utils.L

// func sHash(str string) (hash uint16) {
// 	return uint16(crc32.Checksum([]byte(str), CRC32T))
// }

func mHash(str string) (hash uint32) {
	return crc32.Checksum([]byte(str), CRC32T)
}

/*********************************************************************************
Server send broadcast in periodic to tell every other there is a beat in the
network. every idle 10s will trigger candidate to try take over as Master


**********************************************************************************/

// Source will start by calling .Serv()
// Member will start by calling .Sync()
func NewLansync(rootdir string, excl []string) (
	me *Node, err error) {

	if rootdir[len(rootdir)-1] != '/' {
		rootdir += "/"
	}
	fs, err := os.Stat(rootdir)
	if err != nil {
		err = fmt.Errorf("newbcast>%v", err)
		return
	}
	if !fs.IsDir() {
		err = fmt.Errorf("newbcast>%s:not_a_dir", rootdir)
		return
	}

	rand.Seed(time.Now().Unix())
	me = &Node{
		NoId:     uint16(rand.Int()),
		Server:   nil,
		listenok: make(chan int),
		scanival: TICKS_FILESCAN, //scan interval
		watch:    make(map[int]*FileInfo),
		done:     make(chan struct{}),
		doneResp: make(chan struct{}),
		mfc:      make(chan *FileInfo, 1000),
		Root: &FileInfo{
			fpath:  rootdir,
			member: make(map[uint32]*FileInfo),
			fhash:  mHash(rootdir),
		},
	}
	me.Root.Node = me
	L.Dom = me.NoId
	L.Ctx = 0

	if excl != nil {
		srgx := "(" + strings.Join(excl, "|") + ")"
		if strings.IndexByte(srgx, '.') > 0 {
			srgx = strings.ReplaceAll(srgx, ".", "\\.")
		}
		me.rgxExcl = regexp.MustCompile(srgx)
		L.INF("Success compiling regex: %s", srgx)
	}

	L.INF("Udpcomm and Listening ready.")

	return
}

func NewUdpComm(Node *Node, laddr *net.UDPAddr) (me *udpcomm, err error) {
	me = &udpcomm{
		Node:  Node,
		bread: make([]byte, PKTMaxLength),
		bwrit: make([]byte, PKTMaxLength),
	}
	me.laddr = laddr
	me.conn, err = net.ListenUDP("udp4", me.laddr)
	if err != nil {
		err = fmt.Errorf("newudpcomm>%v", err)
	}
	L.INF("Created UdpComm %v:%d", laddr.IP, laddr.Port)
	return
}

func bcastFile(fpath string) (err error) {

	fi := &FileInfo{
		fpath: fpath,
	}

	if err = fi.open(); err != nil {
		return fmt.Errorf("bcastfile>%v", err)
	}

	//send the header here...
	// BPkt.bcast() //send the header first

	numBlock := fi.FSize / PAGEBLOCKSIZE
	if fi.FSize%PAGEBLOCKSIZE > 0 {
		numBlock++
	}

	var Offset, NewOffset int64
	var n, nread, blockread int
	bblock := make([]byte, PAGEBLOCKSIZE)
	Offset = 0
	EndOfFile := false
	for i := 0; i < int(numBlock); i++ {
		blockread = PAGEBLOCKSIZE
		NewOffset += Offset + int64(blockread)
		if NewOffset > fi.FSize {
			blockread = int(fi.FSize - Offset)
		}
		nread = 0
		for nread < blockread {
			n, err = fi.fo.Read(bblock[nread:])
			nread += n
			if err != nil {
				if err == io.EOF {
					EndOfFile = true
					break
				} else {
					return fmt.Errorf("bcastfile>%v", err)
				}
			}
		}
		numPkt := blockread / PKTMaxPayload
		if blockread%PKTMaxPayload > 0 {
			numPkt++
		}
		// Plen := int64(PKTMaxPayload)
		// bb := bytes.NewBuffer(BPkt.Param[:])
		// for j := 0; j < numPkt; j++ {
		// 	if NewOffset-Offset > Plen {
		// 		Plen = NewOffset - Offset
		// 	}
		// 	copy(BPkt.Payload[:], bblock[Offset:Offset+Plen])
		// 	BPkt.PSize = uint16(Plen)
		// 	BPkt.Seq = byte(j)
		// 	bb.Reset()
		// 	binary.Write(bb, binary.BigEndian, fi.Fhash)

		// 	err = BPkt.bcast() //???
		// 	if err != nil {
		// 		return fmt.Errorf("bpkt.bcast>%v", err)
		// 	}
		// }
		//send of block bcasting, time to check the feedback

		if EndOfFile {
			break
		}
	}

	return

}
